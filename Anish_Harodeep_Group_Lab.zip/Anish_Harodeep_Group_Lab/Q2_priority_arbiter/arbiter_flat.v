/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Fri Oct  9 17:09:21 2026
/////////////////////////////////////////////////////////////


module priority_arbiter_4 ( clk, rst, req, grant );
  input [3:0] req;
  output [3:0] grant;
  input clk, rst;
  wire   n1, n2, n3, n4;
  wire   [3:1] grant_comb;

  DFFR_X1 \grant_reg[3]  ( .D(grant_comb[3]), .CK(clk), .RN(n1), .Q(grant[3])
         );
  DFFR_X1 \grant_reg[2]  ( .D(grant_comb[2]), .CK(clk), .RN(n1), .Q(grant[2])
         );
  DFFR_X1 \grant_reg[1]  ( .D(grant_comb[1]), .CK(clk), .RN(n1), .Q(grant[1])
         );
  DFFR_X1 \grant_reg[0]  ( .D(req[0]), .CK(clk), .RN(n1), .Q(grant[0]) );
  INV_X1 U3 ( .A(rst), .ZN(n1) );
  NOR2_X1 U10 ( .A1(req[0]), .A2(n4), .ZN(grant_comb[1]) );
  INV_X1 U11 ( .A(req[1]), .ZN(n4) );
  NOR4_X1 U12 ( .A1(n2), .A2(req[0]), .A3(req[1]), .A4(req[2]), .ZN(
        grant_comb[3]) );
  INV_X1 U13 ( .A(req[3]), .ZN(n2) );
  NOR3_X1 U14 ( .A1(n3), .A2(req[1]), .A3(req[0]), .ZN(grant_comb[2]) );
  INV_X1 U15 ( .A(req[2]), .ZN(n3) );
endmodule

