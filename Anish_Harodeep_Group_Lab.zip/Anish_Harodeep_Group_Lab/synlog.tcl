history clear
project -load /home/synopsis/H_N_P_EDA/proj_2.prj
project -new /home/synopsis/H_N_P_EDA/proj_3.prj
project_data -active /home/synopsis/H_N_P_EDA/proj_2.prj
project -close /home/synopsis/H_N_P_EDA/proj_2.prj
project -close /home/synopsis/H_N_P_EDA/proj_3.prj
project -new /home/synopsis/Anish_Harodeep_Group_Lab/Q1_barrel_shifter/Q1_barrel_shifter.prj
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q1_barrel_shifter/Q1_barrel_shifter.prj 
add_file -verilog -folder {Q1_barrel_shifter} ./tb_barrel_shifter.v
add_file -verilog -folder {Q1_barrel_shifter} ./barrel_shifter_4bit.v
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q1_barrel_shifter/Q1_barrel_shifter.prj 
project -run  
project -close /home/synopsis/Anish_Harodeep_Group_Lab/Q1_barrel_shifter/Q1_barrel_shifter.prj
project -new /home/synopsis/Anish_Harodeep_Group_Lab/proj_1.prj
project -close /home/synopsis/Anish_Harodeep_Group_Lab/proj_1.prj
project -new /home/synopsis/Anish_Harodeep_Group_Lab/Q2_priority_arbiter/Q2_priority_arbiter.prj
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q2_priority_arbiter/Q2_priority_arbiter.prj 
add_file -verilog -folder {Q2_priority_arbiter} ./priority_arbiter_4.v
add_file -verilog -folder {Q2_priority_arbiter} ./tb_priority_arbiter_4.v
project -run  
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q2_priority_arbiter/Q2_priority_arbiter.prj 
project -close /home/synopsis/Anish_Harodeep_Group_Lab/Q2_priority_arbiter/Q2_priority_arbiter.prj
project -new /home/synopsis/Anish_Harodeep_Group_Lab/Q3_clock_gater/Q3_clock_gater.prj
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q3_clock_gater/Q3_clock_gater.prj 
add_file -verilog -folder {Q3_clock_gater} ./clock_gater.v
add_file -verilog -folder {Q3_clock_gater} ./tb_clock_gater.v
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q3_clock_gater/Q3_clock_gater.prj 
project -run  
project -close /home/synopsis/Anish_Harodeep_Group_Lab/Q3_clock_gater/Q3_clock_gater.prj
project -new /home/synopsis/Anish_Harodeep_Group_Lab/Q4_dual_reg_swap/Q4_dual_reg_swap.prj
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q4_dual_reg_swap/Q4_dual_reg_swap.prj 
add_file -verilog -folder {Q4_dual_reg_swap} ./dual_reg_swap.v
add_file -verilog -folder {Q4_dual_reg_swap} ./tb_dual_reg_swap.v
project -save /home/synopsis/Anish_Harodeep_Group_Lab/Q4_dual_reg_swap/Q4_dual_reg_swap.prj 
project -run  
project -close /home/synopsis/Anish_Harodeep_Group_Lab/Q4_dual_reg_swap/Q4_dual_reg_swap.prj
