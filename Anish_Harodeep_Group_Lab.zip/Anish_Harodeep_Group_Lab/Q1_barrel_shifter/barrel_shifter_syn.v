/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Fri Oct  9 17:09:10 2026
/////////////////////////////////////////////////////////////


module barrel_shifter_4bit ( din, amt, mode, dout );
  input [3:0] din;
  input [1:0] amt;
  input [1:0] mode;
  output [3:0] dout;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15, n16,
         n17, n18, n19, n20, n21, n22, n23, n24, n25, n26;

  NAND2_X1 U30 ( .A1(mode[1]), .A2(mode[0]), .ZN(n12) );
  NAND2_X1 U31 ( .A1(mode[1]), .A2(n10), .ZN(n24) );
  INV_X1 U32 ( .A(n24), .ZN(n9) );
  NOR2_X1 U33 ( .A1(n6), .A2(n7), .ZN(n15) );
  AOI22_X1 U34 ( .A1(n10), .A2(n14), .B1(n15), .B2(n8), .ZN(n17) );
  INV_X1 U35 ( .A(n12), .ZN(n8) );
  INV_X1 U36 ( .A(n20), .ZN(n4) );
  INV_X1 U37 ( .A(n23), .ZN(n5) );
  AOI22_X1 U38 ( .A1(mode[0]), .A2(n14), .B1(n15), .B2(n9), .ZN(n23) );
  OAI211_X1 U39 ( .C1(n17), .C2(n3), .A(n21), .B(n22), .ZN(dout[1]) );
  OAI211_X1 U40 ( .C1(mode[0]), .C2(n9), .A(din[3]), .B(n16), .ZN(n21) );
  AOI22_X1 U41 ( .A1(din[2]), .A2(n5), .B1(din[1]), .B2(n20), .ZN(n22) );
  OAI211_X1 U42 ( .C1(n17), .C2(n2), .A(n18), .B(n19), .ZN(dout[2]) );
  INV_X1 U43 ( .A(din[1]), .ZN(n2) );
  OAI211_X1 U44 ( .C1(n8), .C2(n10), .A(n16), .B(din[0]), .ZN(n18) );
  AOI22_X1 U45 ( .A1(din[3]), .A2(n5), .B1(din[2]), .B2(n20), .ZN(n19) );
  INV_X1 U46 ( .A(mode[0]), .ZN(n10) );
  INV_X1 U47 ( .A(amt[0]), .ZN(n7) );
  INV_X1 U48 ( .A(amt[1]), .ZN(n6) );
  NOR2_X1 U49 ( .A1(n7), .A2(amt[1]), .ZN(n14) );
  NOR2_X1 U50 ( .A1(n6), .A2(amt[0]), .ZN(n16) );
  OAI222_X1 U51 ( .A1(n11), .A2(n12), .B1(n4), .B2(n1), .C1(mode[0]), .C2(n13), 
        .ZN(dout[3]) );
  INV_X1 U52 ( .A(din[3]), .ZN(n1) );
  AOI222_X1 U53 ( .A1(din[0]), .A2(n14), .B1(din[2]), .B2(n15), .C1(din[1]), 
        .C2(n16), .ZN(n11) );
  AOI222_X1 U54 ( .A1(n14), .A2(din[2]), .B1(din[0]), .B2(n15), .C1(din[1]), 
        .C2(n16), .ZN(n13) );
  OAI222_X1 U55 ( .A1(n25), .A2(n24), .B1(n4), .B2(n3), .C1(n26), .C2(n10), 
        .ZN(dout[0]) );
  AOI222_X1 U56 ( .A1(n14), .A2(din[3]), .B1(din[1]), .B2(n15), .C1(n16), .C2(
        din[2]), .ZN(n25) );
  AOI222_X1 U57 ( .A1(n14), .A2(din[1]), .B1(n15), .B2(din[3]), .C1(n16), .C2(
        din[2]), .ZN(n26) );
  NOR2_X1 U58 ( .A1(amt[0]), .A2(amt[1]), .ZN(n20) );
  INV_X1 U59 ( .A(din[0]), .ZN(n3) );
endmodule

