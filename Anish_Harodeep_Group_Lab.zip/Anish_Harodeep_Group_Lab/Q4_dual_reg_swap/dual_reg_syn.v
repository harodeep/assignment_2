/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : V-2023.12-SP3
// Date      : Fri Oct  9 17:09:39 2026
/////////////////////////////////////////////////////////////


module dual_reg_swap ( clk, rst_n, freeze, swap, din, A, B );
  input [7:0] din;
  output [7:0] A;
  output [7:0] B;
  input clk, rst_n, freeze, swap;
  wire   n1, n2, n3, n4, n6, n8, n10, n12, n14, n16, n18, n20, n21, n22, n23,
         n24, n25, n26, n27, n28, n29, n30, n31, n32, n33, n34, n35, n36, n37,
         n38, n39, n40, n41, n42, n43, n44, n45, n46, n47, n48, n49, n50, n51;

  OAI21_X1 U2 ( .B1(n35), .B2(n1), .A(n2), .ZN(n51) );
  AOI22_X1 U3 ( .A1(din[7]), .A2(n3), .B1(n4), .B2(B[7]), .ZN(n2) );
  OAI22_X1 U5 ( .A1(n20), .A2(n1), .B1(n21), .B2(freeze), .ZN(n36) );
  OAI21_X1 U6 ( .B1(n21), .B2(n1), .A(n6), .ZN(n37) );
  AOI22_X1 U7 ( .A1(din[0]), .A2(n3), .B1(n4), .B2(B[0]), .ZN(n6) );
  OAI22_X1 U9 ( .A1(n22), .A2(n1), .B1(n23), .B2(freeze), .ZN(n38) );
  OAI21_X1 U10 ( .B1(n23), .B2(n1), .A(n8), .ZN(n39) );
  AOI22_X1 U11 ( .A1(din[1]), .A2(n3), .B1(n4), .B2(B[1]), .ZN(n8) );
  OAI22_X1 U13 ( .A1(n24), .A2(n1), .B1(n25), .B2(freeze), .ZN(n40) );
  OAI21_X1 U14 ( .B1(n25), .B2(n1), .A(n10), .ZN(n41) );
  AOI22_X1 U15 ( .A1(din[2]), .A2(n3), .B1(n4), .B2(B[2]), .ZN(n10) );
  OAI22_X1 U17 ( .A1(n26), .A2(n1), .B1(n27), .B2(freeze), .ZN(n42) );
  OAI21_X1 U18 ( .B1(n27), .B2(n1), .A(n12), .ZN(n43) );
  AOI22_X1 U19 ( .A1(din[3]), .A2(n3), .B1(n4), .B2(B[3]), .ZN(n12) );
  OAI22_X1 U21 ( .A1(n28), .A2(n1), .B1(n29), .B2(freeze), .ZN(n44) );
  OAI21_X1 U22 ( .B1(n29), .B2(n1), .A(n14), .ZN(n45) );
  AOI22_X1 U23 ( .A1(din[4]), .A2(n3), .B1(n4), .B2(B[4]), .ZN(n14) );
  OAI22_X1 U25 ( .A1(n30), .A2(n1), .B1(n31), .B2(freeze), .ZN(n46) );
  OAI21_X1 U26 ( .B1(n31), .B2(n1), .A(n16), .ZN(n47) );
  AOI22_X1 U27 ( .A1(din[5]), .A2(n3), .B1(n4), .B2(B[5]), .ZN(n16) );
  OAI22_X1 U29 ( .A1(n32), .A2(n1), .B1(n33), .B2(freeze), .ZN(n48) );
  OAI21_X1 U30 ( .B1(n33), .B2(n1), .A(n18), .ZN(n49) );
  AOI22_X1 U31 ( .A1(din[6]), .A2(n3), .B1(n4), .B2(B[6]), .ZN(n18) );
  AND2_X1 U33 ( .A1(swap), .A2(n1), .ZN(n4) );
  NOR2_X1 U34 ( .A1(freeze), .A2(swap), .ZN(n3) );
  OAI22_X1 U35 ( .A1(n34), .A2(n1), .B1(n35), .B2(freeze), .ZN(n50) );
  DFFR_X1 \B_reg[7]  ( .D(n50), .CK(clk), .RN(rst_n), .Q(B[7]), .QN(n34) );
  DFFR_X1 \B_reg[6]  ( .D(n48), .CK(clk), .RN(rst_n), .Q(B[6]), .QN(n32) );
  DFFR_X1 \B_reg[5]  ( .D(n46), .CK(clk), .RN(rst_n), .Q(B[5]), .QN(n30) );
  DFFR_X1 \B_reg[4]  ( .D(n44), .CK(clk), .RN(rst_n), .Q(B[4]), .QN(n28) );
  DFFR_X1 \B_reg[3]  ( .D(n42), .CK(clk), .RN(rst_n), .Q(B[3]), .QN(n26) );
  DFFR_X1 \B_reg[2]  ( .D(n40), .CK(clk), .RN(rst_n), .Q(B[2]), .QN(n24) );
  DFFR_X1 \B_reg[1]  ( .D(n38), .CK(clk), .RN(rst_n), .Q(B[1]), .QN(n22) );
  DFFR_X1 \B_reg[0]  ( .D(n36), .CK(clk), .RN(rst_n), .Q(B[0]), .QN(n20) );
  DFFR_X1 \A_reg[7]  ( .D(n51), .CK(clk), .RN(rst_n), .Q(A[7]), .QN(n35) );
  DFFR_X1 \A_reg[6]  ( .D(n49), .CK(clk), .RN(rst_n), .Q(A[6]), .QN(n33) );
  DFFR_X1 \A_reg[5]  ( .D(n47), .CK(clk), .RN(rst_n), .Q(A[5]), .QN(n31) );
  DFFR_X1 \A_reg[4]  ( .D(n45), .CK(clk), .RN(rst_n), .Q(A[4]), .QN(n29) );
  DFFR_X1 \A_reg[3]  ( .D(n43), .CK(clk), .RN(rst_n), .Q(A[3]), .QN(n27) );
  DFFR_X1 \A_reg[2]  ( .D(n41), .CK(clk), .RN(rst_n), .Q(A[2]), .QN(n25) );
  DFFR_X1 \A_reg[1]  ( .D(n39), .CK(clk), .RN(rst_n), .Q(A[1]), .QN(n23) );
  DFFR_X1 \A_reg[0]  ( .D(n37), .CK(clk), .RN(rst_n), .Q(A[0]), .QN(n21) );
  INV_X1 U37 ( .A(freeze), .ZN(n1) );
endmodule

